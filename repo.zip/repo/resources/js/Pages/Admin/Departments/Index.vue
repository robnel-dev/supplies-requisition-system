<script setup>
import { ref } from 'vue';
import { Head, useForm } from '@inertiajs/vue3';
import { Plus } from 'lucide-vue-next'; // 👈 Added icon
import AppLayout from '@/Layouts/AppLayout.vue'; // 👈 Switched to your AppLayout
import Modal from '@/Components/Modal.vue';
import InputLabel from '@/Components/InputLabel.vue';
import TextInput from '@/Components/TextInput.vue';
import InputError from '@/Components/InputError.vue';
import SecondaryButton from '@/Components/SecondaryButton.vue';

const props = defineProps({
    departments: Array,
});

const isModalOpen = ref(false);

const form = useForm({
    name: '',
    code: '',
    type: 'head_office',
});

const openModal = () => isModalOpen.value = true;

const closeModal = () => {
    isModalOpen.value = false;
    form.reset();
    form.clearErrors();
};

const submit = () => {
    form.post(route('admin.departments.store'), {
        onSuccess: () => closeModal(),
        preserveScroll: true,
    });
};
</script>

<template>
    <Head title="Departments" />

    <AppLayout>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            
            <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
                <h2 class="text-2xl font-bold text-brand-navy tracking-tight">Department Management</h2>
                
                <button @click="openModal" class="inline-flex items-center px-4 py-2.5 bg-brand-blue hover:bg-brand-blue/90 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors focus:ring-2 focus:ring-brand-blue/50 focus:outline-none">
                    <Plus class="w-4 h-4 mr-2" />
                    Add Department
                </button>
            </div>

            <div class="bg-white rounded-xl shadow-[0_2px_10px_-3px_rgba(6,81,237,0.1)] border border-gray-100 overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-sm whitespace-nowrap">
                        <thead class="bg-gray-50/80 border-b border-gray-100 uppercase tracking-wider text-[11px] font-bold text-gray-500">
                            <tr>
                                <th class="px-6 py-4">Department Code</th>
                                <th class="px-6 py-4">Department Name</th>
                                <th class="px-6 py-4">Location Type</th>
                                <th class="px-6 py-4 text-center">Assigned Users</th>
                                <th class="px-6 py-4 text-right">Date Added</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-50">
                            <tr v-for="dept in departments" :key="dept.id" class="hover:bg-brand-blue/5 transition-colors">
                                <td class="px-6 py-4 font-bold text-brand-navy">{{ dept.code }}</td>
                                <td class="px-6 py-4 font-medium text-gray-900">{{ dept.name }}</td>
                                <td class="px-6 py-4">
                                    <span :class="[
                                        'px-2.5 py-1 rounded-full text-xs font-semibold',
                                        dept.type === 'head_office' ? 'bg-purple-50 text-purple-700' : 'bg-brand-yellow/10 text-yellow-800'
                                    ]">
                                        {{ dept.type.replace('_', ' ').toUpperCase() }}
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-center">
                                    <span class="inline-flex items-center justify-center w-6 h-6 rounded-full bg-brand-navy/10 text-brand-navy font-bold text-xs">
                                        {{ dept.users_count || 0 }}
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-right text-gray-500 text-xs font-medium">
                                    {{ new Date(dept.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) }}
                                </td>
                            </tr>
                            <tr v-if="departments.length === 0">
                                <td colspan="5" class="px-6 py-12 text-center text-gray-400">
                                    No departments found. Click "Add Department" to get started.
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <Modal :show="isModalOpen" @close="closeModal">
            <div class="p-6">
                <h2 class="text-lg font-bold text-brand-navy mb-4">Add New Department</h2>
                <form @submit.prevent="submit">
                    <div class="mb-4">
                        <InputLabel for="code" value="Department Code / Area Number" />
                        <TextInput id="code" v-model="form.code" type="text" class="mt-1 block w-full" placeholder="e.g., HRD-001" />
                        <InputError :message="form.errors.code" class="mt-2" />
                    </div>
                    <div class="mb-4">
                        <InputLabel for="name" value="Department / Area Name" />
                        <TextInput id="name" v-model="form.name" type="text" class="mt-1 block w-full" placeholder="e.g., Human Resources" />
                        <InputError :message="form.errors.name" class="mt-2" />
                    </div>
                    <div class="mb-6">
                        <InputLabel for="type" value="Location Type" />
                        <select id="type" v-model="form.type" class="mt-1 block w-full border-gray-300 focus:border-brand-blue focus:ring-brand-blue rounded-md shadow-sm">
                            <option value="head_office">Head Office</option>
                            <option value="store">Store Area</option>
                        </select>
                        <InputError :message="form.errors.type" class="mt-2" />
                    </div>
                    <div class="flex justify-end space-x-3">
                        <SecondaryButton @click="closeModal">Cancel</SecondaryButton>
                        <button type="submit" :disabled="form.processing" class="inline-flex items-center px-4 py-2 bg-brand-blue hover:bg-brand-blue/90 text-white text-sm font-semibold rounded-md shadow-sm transition-colors disabled:opacity-50">
                            Save Department
                        </button>
                    </div>
                </form>
            </div>
        </Modal>
    </AppLayout>
</template>