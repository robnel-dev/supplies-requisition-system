<script setup>
import { ref } from 'vue';
import { Head, useForm } from '@inertiajs/vue3';
import { Plus } from 'lucide-vue-next';
import AppLayout from '@/Layouts/AppLayout.vue';
import Modal from '@/Components/Modal.vue';
import InputLabel from '@/Components/InputLabel.vue';
import TextInput from '@/Components/TextInput.vue';
import InputError from '@/Components/InputError.vue';
import SecondaryButton from '@/Components/SecondaryButton.vue';

const props = defineProps({
    users: Array,
    departments: Array,
});

const isModalOpen = ref(false);

const form = useForm({
    name: '',
    email: '',
    role: 'requestor',
    department_id: '',
    cost_center: '',
    password: '',
    password_confirmation: '',
});

const openModal = () => isModalOpen.value = true;

const closeModal = () => {
    isModalOpen.value = false;
    form.reset();
    form.clearErrors();
};

const submit = () => {
    form.post(route('admin.users.store'), {
        onSuccess: () => closeModal(),
    });
};
</script>

<template>
    <Head title="Users" />

    <AppLayout>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            
            <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
                <h2 class="text-2xl font-bold text-brand-navy tracking-tight">User Management</h2>
                
                <button @click="openModal" class="inline-flex items-center px-4 py-2.5 bg-brand-blue hover:bg-brand-blue/90 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors focus:ring-2 focus:ring-brand-blue/50 focus:outline-none">
                    <Plus class="w-4 h-4 mr-2" />
                    Add User
                </button>
            </div>

            <div class="bg-white rounded-xl shadow-[0_2px_10px_-3px_rgba(6,81,237,0.1)] border border-gray-100 overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-sm whitespace-nowrap">
                        <thead class="bg-gray-50/80 border-b border-gray-100 uppercase tracking-wider text-[11px] font-bold text-gray-500">
                            <tr>
                                <th class="px-6 py-4">Account Name</th>
                                <th class="px-6 py-4">Email Address</th>
                                <th class="px-6 py-4">User Role</th>
                                <th class="px-6 py-4">Department / Area</th>
                                <th class="px-6 py-4">Cost Center</th>
                                <th class="px-6 py-4 text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-50">
                            <tr v-for="user in users" :key="user.id" class="hover:bg-brand-blue/5 transition-colors">
                                <td class="px-6 py-4 font-bold text-brand-navy">{{ user.name }}</td>
                                <td class="px-6 py-4 text-gray-600">{{ user.email }}</td>
                                <td class="px-6 py-4">
                                    <span :class="[
                                        'px-2.5 py-1 rounded-full text-[11px] font-bold tracking-wide uppercase',
                                        user.role === 'hr_admin' ? 'bg-brand-navy text-white' : 
                                        user.role === 'approver' ? 'bg-brand-yellow/20 text-yellow-800' : 
                                        'bg-brand-blue/10 text-brand-blue'
                                    ]">
                                        {{ user.role.replace('_', ' ') }}
                                    </span>
                                </td>
                                <td class="px-6 py-4 font-medium text-gray-800">{{ user.department ? user.department.name : '—' }}</td>
                                <td class="px-6 py-4 text-gray-600">{{ user.cost_center }}</td>
                                <td class="px-6 py-4 text-center">
                                    <span v-if="user.is_active" class="px-2 py-1 bg-emerald-50 text-emerald-600 border border-emerald-200 rounded-md text-[11px] font-bold uppercase tracking-wider">Active</span>
                                    <span v-else class="px-2 py-1 bg-red-50 text-red-600 border border-red-200 rounded-md text-[11px] font-bold uppercase tracking-wider">Disabled</span>
                                </td>
                            </tr>
                            <tr v-if="users.length === 0">
                                <td colspan="6" class="px-6 py-12 text-center text-gray-400">
                                    No users found.
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <Modal :show="isModalOpen" @close="closeModal">
            <div class="p-6">
                <h2 class="text-lg font-bold text-brand-navy mb-4">Add New User</h2>
                <form @submit.prevent="submit" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <InputLabel for="name" value="Account Name" />
                        <TextInput id="name" v-model="form.name" type="text" class="mt-1 block w-full focus:border-brand-blue focus:ring-brand-blue" />
                        <InputError :message="form.errors.name" class="mt-2" />
                    </div>
                    <div>
                        <InputLabel for="email" value="Email Address" />
                        <TextInput id="email" v-model="form.email" type="email" class="mt-1 block w-full focus:border-brand-blue focus:ring-brand-blue" />
                        <InputError :message="form.errors.email" class="mt-2" />
                    </div>
                    <div>
                        <InputLabel for="role" value="User Role" />
                        <select id="role" v-model="form.role" class="mt-1 block w-full border-gray-300 focus:border-brand-blue focus:ring-brand-blue rounded-md shadow-sm">
                            <option value="requestor">Requestor</option>
                            <option value="approver">Approver</option>
                            <option value="hr_admin">HR Admin</option>
                        </select>
                        <InputError :message="form.errors.role" class="mt-2" />
                    </div>
                    <div>
                        <InputLabel for="department_id" value="Department / Area" />
                        <select id="department_id" v-model="form.department_id" class="mt-1 block w-full border-gray-300 focus:border-brand-blue focus:ring-brand-blue rounded-md shadow-sm">
                            <option value="">Select Department</option>
                            <option v-for="dept in departments" :key="dept.id" :value="dept.id">
                                {{ dept.name }} ({{ dept.code }})
                            </option>
                        </select>
                        <InputError :message="form.errors.department_id" class="mt-2" />
                    </div>
                    <div class="md:col-span-2">
                        <InputLabel for="cost_center" value="Cost Center" />
                        <TextInput id="cost_center" v-model="form.cost_center" type="text" class="mt-1 block w-full focus:border-brand-blue focus:ring-brand-blue" />
                        <InputError :message="form.errors.cost_center" class="mt-2" />
                    </div>
                    <div>
                        <InputLabel for="password" value="Password" />
                        <TextInput id="password" v-model="form.password" type="password" class="mt-1 block w-full focus:border-brand-blue focus:ring-brand-blue" />
                        <InputError :message="form.errors.password" class="mt-2" />
                    </div>
                    <div>
                        <InputLabel for="password_confirmation" value="Confirm Password" />
                        <TextInput id="password_confirmation" v-model="form.password_confirmation" type="password" class="mt-1 block w-full focus:border-brand-blue focus:ring-brand-blue" />
                    </div>
                    <div class="mt-6 flex justify-end space-x-3 md:col-span-2">
                        <SecondaryButton @click="closeModal">Cancel</SecondaryButton>
                        <button type="submit" :disabled="form.processing" class="inline-flex items-center px-4 py-2 bg-brand-blue hover:bg-brand-blue/90 text-white text-sm font-semibold rounded-md shadow-sm transition-colors disabled:opacity-50">
                            Save User
                        </button>
                    </div>
                </form>
            </div>
        </Modal>
    </AppLayout>
</template>