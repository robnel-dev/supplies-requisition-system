<script setup>
import AppLayout from '@/Layouts/AppLayout.vue';
import { Head } from '@inertiajs/vue3';
</script>

<template>
    <Head title="Dashboard" />

    <AppLayout>
        <div class="mb-6">
            <h2 class="text-2xl font-black text-brand-navy tracking-tight">Dashboard</h2>
            <p class="mt-1 text-sm text-gray-500">Welcome back! Here is an overview of your requests.</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            
            <div class="bg-white shadow-sm ring-1 ring-gray-900/5 rounded-xl p-6 transition-all hover:shadow-md">
                <div class="text-gray-500 text-xs font-bold uppercase tracking-wider">Total Requests</div>
                <div class="mt-2 text-3xl font-black text-brand-navy">4</div>
            </div>
            
            </div>
    </AppLayout>
</template>
