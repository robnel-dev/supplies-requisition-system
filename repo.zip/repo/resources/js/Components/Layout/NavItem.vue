<script setup>
import { Link, usePage } from '@inertiajs/vue3';

const page = usePage();
const isActive = (href) => page.url === href || page.url.startsWith(href + '/');

defineProps({
    item: Object
});
</script>

<template>
    <Link :href="item.href" :class="[
        isActive(item.href)
            ? 'bg-brand-navy text-white shadow-md'
            : 'text-gray-600 hover:bg-brand-navy hover:text-white',
        'group flex items-center px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 hover:scale-[1.03] active:scale-[0.95]'
    ]">
        <component :is="item.icon" :class="[
            isActive(item.href)
                ? 'text-brand-blue'
                : 'text-gray-400 group-hover:text-brand-blue',
            'mr-3 flex-shrink-0 w-5 h-5 transition-colors duration-200'
        ]" />
        {{ item.name }}
    </Link>
</template>